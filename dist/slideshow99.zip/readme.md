20210705

CF7Slide.a99 - original tool, just a demo program, requires CF7
SlideShow.a99 - improved new tool intended to be more flexible

Run from the DSK or from the TIFILES 'EA5' file. Lets you select up to 9 disk paths and will view all TI Artist style images on those paths. Supports the following image types:

TI ARTIST+ Color
TI ARTIST+ Monochrome only
Half Multicolor
F18A Paletted Bitmap (with F18A)
F18A Scanline paletted Bitmap (with F18A)

